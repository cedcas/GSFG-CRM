    <?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

    $manifest = array (
         'acceptable_sugar_versions' => 
          array (
            '6.1.4'
          ),
          'acceptable_sugar_flavors' =>
          array(
            'CE', 'PRO','ENT'
          ),
          'readme'=>'',
          'key'=>'',
          'author' => '',
          'description' => '',
          'icon' => '',
          'is_uninstallable' => true,
          'name' => 'Leads',
          'published_date' => '2012-10-09 21:12:31',
          'type' => 'module',
          'version' => '1349817151',
          'remove_tables' => 'prompt',
          );
$installdefs = array (
  'id' => 'Leads',
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/en_us.Leads.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/language/en_us.lang.php',
      'to_module' => 'Leads',
      'language' => 'en_us',
    ),
  ),
  'custom_fields' => 
  array (
    'Leadsspouse_first_name_c' => 
    array (
      'id' => 'Leadsspouse_first_name_c',
      'name' => 'spouse_first_name_c',
      'label' => 'LBL_SPOUSE_FIRST_NAME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '50',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:23:07',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsspouse_last_name_c' => 
    array (
      'id' => 'Leadsspouse_last_name_c',
      'name' => 'spouse_last_name_c',
      'label' => 'LBL_SPOUSE_LAST_NAME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '50',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:23:34',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsspouse_social_security_numbe_c' => 
    array (
      'id' => 'Leadsspouse_social_security_numbe_c',
      'name' => 'spouse_social_security_numbe_c',
      'label' => 'LBL_SPOUSE_SOCIAL_SECURITY_NUMBE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '12',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:50:08',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsspouse_age_c' => 
    array (
      'id' => 'Leadsspouse_age_c',
      'name' => 'spouse_age_c',
      'label' => 'LBL_SPOUSE_AGE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '3',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:50:40',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsspouse_date_of_birth_c' => 
    array (
      'id' => 'Leadsspouse_date_of_birth_c',
      'name' => 'spouse_date_of_birth_c',
      'label' => 'LBL_SPOUSE_DATE_OF_BIRTH',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'date',
      'max_size' => NULL,
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:51:30',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsspouse_drivers_license_numbe_c' => 
    array (
      'id' => 'Leadsspouse_drivers_license_numbe_c',
      'name' => 'spouse_drivers_license_numbe_c',
      'label' => 'LBL_SPOUSE_DRIVERS_LICENSE_NUMBE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '16',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:52:41',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsage_c' => 
    array (
      'id' => 'Leadsage_c',
      'name' => 'age_c',
      'label' => 'LBL_AGE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '3',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:53:27',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsdate_of_birth_c' => 
    array (
      'id' => 'Leadsdate_of_birth_c',
      'name' => 'date_of_birth_c',
      'label' => 'LBL_DATE_OF_BIRTH',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'date',
      'max_size' => NULL,
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:53:51',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsdrivers_license_number_c' => 
    array (
      'id' => 'Leadsdrivers_license_number_c',
      'name' => 'drivers_license_number_c',
      'label' => 'LBL_DRIVERS_LICENSE_NUMBER',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '16',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:54:23',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadssocial_security_number_c' => 
    array (
      'id' => 'Leadssocial_security_number_c',
      'name' => 'social_security_number_c',
      'label' => 'LBL_SOCIAL_SECURITY_NUMBER',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '12',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-01 03:54:53',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsmeeting_attended_c' => 
    array (
      'id' => 'Leadsmeeting_attended_c',
      'name' => 'meeting_attended_c',
      'label' => 'LBL_MEETING_ATTENDED',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'bool',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => '0',
      'date_modified' => '2011-02-01 03:56:30',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsgsf_seminardetails_id_c' => 
    array (
      'id' => 'Leadsgsf_seminardetails_id_c',
      'name' => 'gsf_seminardetails_id_c',
      'label' => 'LBL_LIST_RELATED_TO',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'id',
      'max_size' => '36',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-03-04 01:33:21',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_venue_c' => 
    array (
      'id' => 'Leadsseminar_venue_c',
      'name' => 'seminar_venue_c',
      'label' => 'LBL_SEMINAR_VENUE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'relate',
      'max_size' => '255',
      'require_option' => '1',
      'default_value' => NULL,
      'date_modified' => '2011-03-24 02:21:34',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => 'GSF_SeminarDetails',
      'ext3' => 'gsf_seminardetails_id_c',
      'ext4' => NULL,
    ),
    'Leadsseminar_venue_name_c' => 
    array (
      'id' => 'Leadsseminar_venue_name_c',
      'name' => 'seminar_venue_name_c',
      'label' => 'LBL_SEMINAR_VENUE_NAME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '50',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-03-02 05:32:16',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_date_c' => 
    array (
      'id' => 'Leadsseminar_date_c',
      'name' => 'seminar_date_c',
      'label' => 'LBL_SEMINAR_DATE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '20',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-03-02 05:33:21',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_time_c' => 
    array (
      'id' => 'Leadsseminar_time_c',
      'name' => 'seminar_time_c',
      'label' => 'LBL_SEMINAR_TIME',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '20',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-18 05:45:10',
      'deleted' => '0',
      'audited' => '1',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_city_c' => 
    array (
      'id' => 'Leadsseminar_city_c',
      'name' => 'seminar_city_c',
      'label' => 'LBL_SEMINAR_CITY',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-18 05:48:47',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_state_c' => 
    array (
      'id' => 'Leadsseminar_state_c',
      'name' => 'seminar_state_c',
      'label' => 'LBL_SEMINAR_STATE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-18 05:48:47',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_postalcode_c' => 
    array (
      'id' => 'Leadsseminar_postalcode_c',
      'name' => 'seminar_postalcode_c',
      'label' => 'LBL_SEMINAR_POSTALCODE',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '20',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-18 05:48:47',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_days_left_c' => 
    array (
      'id' => 'Leadsseminar_days_left_c',
      'name' => 'seminar_days_left_c',
      'label' => 'LBL_SEMINAR_DAYS_LEFT',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '5',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-18 05:51:39',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_address_c' => 
    array (
      'id' => 'Leadsseminar_address_c',
      'name' => 'seminar_address_c',
      'label' => 'LBL_SEMINAR_ADDRESS',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-02-18 05:49:44',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsseminar_attended_c' => 
    array (
      'id' => 'Leadsseminar_attended_c',
      'name' => 'seminar_attended_c',
      'label' => 'LBL_SEMINAR_ATTENDED',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'bool',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => '0',
      'date_modified' => '2011-03-19 08:46:49',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsmeeting_date_c' => 
    array (
      'id' => 'Leadsmeeting_date_c',
      'name' => 'meeting_date_c',
      'label' => 'LBL_MEETING_DATE',
      'comments' => 'Meeting Date',
      'help' => 'Meeting Date',
      'module' => 'Leads',
      'type' => 'date',
      'max_size' => NULL,
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2011-08-03 12:11:21',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsgroup_referral_c' => 
    array (
      'id' => 'Leadsgroup_referral_c',
      'name' => 'group_referral_c',
      'label' => 'LBL_GROUP_REFERRAL',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2012-10-09 17:29:11',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsfutureassets_c' => 
    array (
      'id' => 'Leadsfutureassets_c',
      'name' => 'futureassets_c',
      'label' => 'LBL_FUTUREASSETS',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'enum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2012-09-27 15:38:50',
      'deleted' => '0',
      'audited' => '1',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'gsf_future_assets_list',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsreferred_by_c' => 
    array (
      'id' => 'Leadsreferred_by_c',
      'name' => 'referred_by_c',
      'label' => 'LBL_REFERRED_BY',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'varchar',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2012-09-04 16:58:57',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsreferred_c' => 
    array (
      'id' => 'Leadsreferred_c',
      'name' => 'referred_c',
      'label' => 'LBL_REFERRED',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'bool',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => '0',
      'date_modified' => '2012-09-04 16:58:22',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsambassador_c' => 
    array (
      'id' => 'Leadsambassador_c',
      'name' => 'ambassador_c',
      'label' => 'LBL_AMBASSADOR',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'bool',
      'max_size' => '255',
      'require_option' => '0',
      'default_value' => '0',
      'date_modified' => '2012-08-14 19:58:33',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsclientranking_c' => 
    array (
      'id' => 'Leadsclientranking_c',
      'name' => 'clientranking_c',
      'label' => 'LBL_CLIENTRANKING',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'multienum',
      'max_size' => '100',
      'require_option' => '0',
      'default_value' => '^0^',
      'date_modified' => '2012-09-04 17:25:49',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '1',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'importable' => 'true',
      'ext1' => 'account_type_dom',
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => '^0^',
    ),
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/detailviewdefs.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/detailviewdefs.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php_030311',
      'to' => 'custom/modules/Leads/metadata/detailviewdefs.php_030311',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/detailviewdefs.php_030311',
      'to' => 'custom/working/modules/Leads/metadata/detailviewdefs.php_030311',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/editviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/editviewdefs.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/editviewdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/editviewdefs.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/editviewdefs.php_030211',
      'to' => 'custom/modules/Leads/metadata/editviewdefs.php_030211',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/editviewdefs.php_030211',
      'to' => 'custom/working/modules/Leads/metadata/editviewdefs.php_030211',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/listviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/listviewdefs.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/popupdefs.php',
      'to' => 'custom/modules/Leads/metadata/popupdefs.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/popupdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/popupdefs.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/searchdefs.php',
      'to' => 'custom/modules/Leads/metadata/searchdefs.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Leads/metadata/searchdefs.php',
      'to' => 'custom/working/modules/Leads/metadata/searchdefs.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Language/en_us.custom_labels.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.custom_labels.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Layoutdefs/_overrideLead_subpanel_accounts.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Layoutdefs/_overrideLead_subpanel_accounts.php',
    ),
    15 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Layoutdefs/custom_layoutdefs.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Layoutdefs/custom_layoutdefs.php',
    ),
    16 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/custom_aged.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/custom_aged.php',
    ),
    17 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/custom_fields.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/custom_fields.php',
    ),
    18 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/gsf_seminardetails_leads_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/gsf_seminardetails_leads_Leads.php',
    ),
    19 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_age_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_age_c.php',
    ),
    20 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_ambassador_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_ambassador_c.php',
    ),
    21 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_clientranking_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_clientranking_c.php',
    ),
    22 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_date_of_birth_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_date_of_birth_c.php',
    ),
    23 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_drivers_license_number_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_drivers_license_number_c.php',
    ),
    24 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_futureassets_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_futureassets_c.php',
    ),
    25 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_group_referral_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_group_referral_c.php',
    ),
    26 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_gsf_seminardetails_id_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_gsf_seminardetails_id_c.php',
    ),
    27 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_meeting_attended_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_meeting_attended_c.php',
    ),
    28 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_meeting_date_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_meeting_date_c.php',
    ),
    29 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_referred_by_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_referred_by_c.php',
    ),
    30 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_referred_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_referred_c.php',
    ),
    31 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_address_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_address_c.php',
    ),
    32 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_attended_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_attended_c.php',
    ),
    33 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_city_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_city_c.php',
    ),
    34 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_date_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_date_c.php',
    ),
    35 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_days_left_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_days_left_c.php',
    ),
    36 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_postalcode_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_postalcode_c.php',
    ),
    37 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_state_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_state_c.php',
    ),
    38 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_time_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_time_c.php',
    ),
    39 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_venue_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_venue_c.php',
    ),
    40 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_venue_name_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_seminar_venue_name_c.php',
    ),
    41 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_social_security_number_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_social_security_number_c.php',
    ),
    42 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_age_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_age_c.php',
    ),
    43 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_date_of_birth_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_date_of_birth_c.php',
    ),
    44 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_drivers_license_numbe_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_drivers_license_numbe_c.php',
    ),
    45 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_first_name_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_first_name_c.php',
    ),
    46 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_last_name_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_last_name_c.php',
    ),
    47 => 
    array (
      'from' => '<basepath>/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_social_security_numbe_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_spouse_social_security_numbe_c.php',
    ),
  ),
);