<?php
//auto-generated file DO NOT EDIT
$layout_defs['Leads']['subpanel_setup']['accounts']['override_subpanel_name'] = 'Lead_subpanel_accounts';
?>