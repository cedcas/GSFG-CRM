<?php

$mod_strings['LBL_SEMINAR_CAPACITY'] = 'Capacity';
$mod_strings['LBL_ACCOUNT_UPCOMING_ANNIV'] = 'Upcoming Anniversary (Account)';
$mod_strings['LBL_ACCOUNT_DAYS_LEFT_TO_ANNIV'] = 'Days Left Prior to Anniversary';
$mod_strings['LBL_ACCOUNT_LAST_ANNIV_PROCESSED'] = 'Last Anniversary Processed';
$mod_strings['LBL_ACCOUNTS'] = 'Accounts';
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Accounts';
$mod_strings['LBL_DOCUMENTS'] = 'Documents';
$mod_strings['LBL_DOCUMENTS_SUBPANEL_TITLE'] = 'Documents';
$mod_strings['LBL_REPEAT_BUSINESS_PREMIUM'] = 'Repeat Business Premium';
$mod_strings['LBL_TOTAL_PREMIUM'] = 'Total Premium';
$mod_strings['LBL_REPEAT_BUSINESS_RATIO'] = 'Ratio';
$mod_strings['LBL_ATTENDEE_ID'] = 'Attendee ID';
$mod_strings['LBL_MAIN_ATTENDEE_ID'] = 'Main Attendee ID';
$mod_strings['LBL_ACCOUNTS_TOTAL_PREMIUM'] = 'Accounts Total Premium';
$mod_strings['LBL_ACCOUNTS_ACCOUNTS_TOTAL_PREMIUM_AVERAGE'] = 'Accounts Total Premium Average';
$mod_strings['LBL_SEMINAR_TITLE'] = 'Seminar Title';
$mod_strings['LBL_BEFORE_MEETING_START'] = 'Before Meeting Time';
$mod_strings['LBL_AFTER_MEETING_START'] = 'After Meeting Time';
$mod_strings['LBL_VENUE_LOGO_IMG'] = 'Venu Logo IMG';
$mod_strings['LBL_VENUE_LOGO_FILENAME'] = 'Venue Logo File Name';
?>