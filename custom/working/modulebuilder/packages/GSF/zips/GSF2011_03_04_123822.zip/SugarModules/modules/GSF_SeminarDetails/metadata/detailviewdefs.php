<?php
$module_name = 'GSF_SeminarDetails';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'details_venue',
            'studio' => 'visible',
            'label' => 'LBL_DETAILS_VENUE',
          ),
          1 => 
          array (
            'name' => 'details_venue_address1',
            'label' => 'LBL_DETAILS_VENUE_ADDRESS1',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'details_venue_city',
            'label' => 'LBL_DETAILS_VENUE_CITY',
          ),
          1 => 
          array (
            'name' => 'details_venue_state',
            'label' => 'LBL_DETAILS_VENUE_STATE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'details_venue_postalcode',
            'label' => 'LBL_DETAILS_VENUE_POSTALCODE',
          ),
          1 => 
          array (
            'name' => 'details_registered',
            'label' => 'LBL_DETAILS_REGISTERED',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'details_from_date',
            'label' => 'LBL_DETAILS_FROM_DATE',
          ),
          1 => 
          array (
            'name' => 'details_from_time',
            'studio' => 'visible',
            'label' => 'LBL_DETAILS_FROM_TIME',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'details_to_date',
            'label' => 'LBL_DETAILS_TO_DATE',
          ),
          1 => 
          array (
            'name' => 'details_to_time',
            'studio' => 'visible',
            'label' => 'LBL_DETAILS_TO_TIME',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'details_buts_in_sits',
            'label' => 'LBL_DETAILS_BUTS_IN_SITS',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'details_amount_per_person',
            'label' => 'LBL_DETAILS_AMOUNT_PER_PERSON',
          ),
          1 => 
          array (
            'name' => 'details_buying_units',
            'label' => 'LBL_DETAILS_BUYING_UNITS',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'details_total_amount',
            'label' => 'LBL_DETAILS_TOTAL_AMOUNT',
          ),
          1 => 
          array (
            'name' => 'details_blue_sheets',
            'label' => 'LBL_DETAILS_BLUE_SHEETS',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'studio' => 'visible',
            'label' => 'LBL_DESCRIPTION',
          ),
          1 => 
          array (
            'name' => 'details_appointment_sets',
            'label' => 'LBL_DETAILS_APPOINTMENT_SETS',
          ),
        ),
      ),
    ),
  ),
);
?>
