<?php
$module_name = 'GSF_Withdrawals';
$OBJECT_NAME = 'GSF_WITHDRAWALS';
$listViewDefs [$module_name] = 
array (
  'GSF_WITHDRAWAL_AMOUNT' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_GSF_WITHDRAWAL_AMOUNT',
    'currency_format' => true,
    'width' => '25%',
    'default' => true,
  ),
  'GSF_WITHDRAWAL_TYPE' => 
  array (
    'width' => '25%',
    'label' => 'LBL_TYPE',
    'default' => true,
  ),
  'GSF_WITHDRAWAL_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_GSF_WITHDRAWAL_DATE',
    'width' => '20%',
    'default' => true,
  ),
  'CREATED_BY_NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_CREATED',
    'default' => true,
  ),
  'GSF_WITHDRAWALS_TYPE' => 
  array (
    'type' => 'enum',
    'label' => 'LBL_TYPE',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'PROBABILITY' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PROBABILITY',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'width' => '10%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'width' => '5%',
    'label' => 'LBL_MODIFIED',
    'default' => false,
  ),
);
?>
